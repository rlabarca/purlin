#!/bin/bash
# usage: run.sh <person> <logname> <prompt> [resume-session-id]
W=/tmp/claude-0/-home-user-purlin/cfab07d7-d915-507a-96e3-796076546982/scratchpad/lab
P=$1; L=$2; PROMPT=$3; R=$4
cd $W/$P || exit 1
MODEL=${MODEL:-claude-haiku-4-5-20251001}
args=(-p "$PROMPT" --model "$MODEL" --dangerously-skip-permissions --output-format stream-json --verbose)
if [ -n "$R" ]; then args+=(--resume "$R"); else args+=(--session-id "$(python3 -c "import uuid;print(uuid.uuid4())")"); fi
start=$(date +%s)
env -u CLAUDE_CODE_ADDITIONAL_DIRECTORIES_CLAUDE_MD -u CLAUDE_ADDITIONAL_DIRECTORIES -u CLAUDECODE -u CLAUDE_CODE_SESSION_ID IS_SANDBOX=1 \
  claude "${args[@]}" > $W/logs/$L.jsonl 2> $W/logs/$L.err
rc=$?
end=$(date +%s)
python3 - "$W/logs/$L.jsonl" $((end-start)) $rc <<'PY'
import json,sys
f,secs,rc=sys.argv[1],sys.argv[2],sys.argv[3]
res=None;sid=None
for line in open(f):
    try: e=json.loads(line)
    except: continue
    if e.get('type')=='system' and e.get('subtype')=='init': sid=e.get('session_id')
    if e.get('type')=='result': res=e
print(f"== rc={rc} wall={secs}s session={sid}")
if res:
    print(f"== cost=${res.get('total_cost_usd')} turns={res.get('num_turns')} dur={res.get('duration_ms')}ms err={res.get('is_error')}")
    print(res.get('result'))
PY
