# Feature: sample-age

> Description: Calculate sample age at receipt and reject samples exceeding tube type stability windows. Age is the real elapsed time from collection to receipt, accounting for timezones and daylight saving transitions.
> Scope: src/intake.py, src/models.py, tests/
> Highest-Rule: 9
> Highest-Proof: 9

## Rules

- RULE-1: Calculate sample age as received_time minus collection_time
- RULE-2: Handle timezone differences when collection and receipt are in different timezones
- RULE-3: Handle daylight saving time transitions within the sample age window
- RULE-4: Reject SST (gold top) tube samples older than 72 hours
- RULE-5: Reject EDTA (lavender top) tube samples older than 24 hours
- RULE-6: Accept samples within their stability window without rejection
- RULE-7: Rejection messages read clearly to a lab technician
- RULE-8: End-to-end intake processes a full day's batch of samples through age validation
- RULE-9: Reject samples where collection_time is after receipt_time (data-entry error)

## Proof

- PROOF-1 (RULE-1): A sample collected at 2024-01-15 10:00 UTC and received at 2024-01-15 14:30 UTC; age is 4.5 hours
- PROOF-2 (RULE-2): A sample collected at 2024-01-15 10:00 PST and received at 2024-01-15 13:00 EST (same instant); age is 0 hours
- PROOF-3 (RULE-3): A sample collected 12 hours before a DST transition in the collection timezone and received 12 hours after the transition in the receipt timezone; age is 24 hours elapsed time, not affected by the 1-hour clock shift
- PROOF-4 (RULE-4): An SST sample collected 73 hours before receipt is rejected
- PROOF-5 (RULE-5): An EDTA sample collected 25 hours before receipt is rejected
- PROOF-6 (RULE-6): An SST sample 71 hours old and an EDTA sample 23 hours old are both accepted without rejection
- PROOF-7 @manual (RULE-7): A rejection message for an aged sample is reviewed by a lab technician who confirms it is clear and actionable
- PROOF-8 @slow (RULE-8): A full day's batch of samples with mixed ages and tube types is processed through intake; aged samples are rejected and fresh samples are accepted
- PROOF-9 (RULE-9): A sample with collection_time of 2024-01-15 15:00 UTC and receipt_time of 2024-01-15 14:00 UTC is rejected as a data-entry error

